<?php

// Insert products to database
function insert_products_to_db_callback() {

    ob_start();

    // File path
    $file_path = __DIR__ . '/uploads/api_data.json';

    $productJson  = file_get_contents( $file_path );
    $productArray = json_decode( $productJson, true );

    global $wpdb;
    $table_name = $wpdb->prefix . 'sync_products';
    truncate_table( $table_name );

    // Insert to database
    foreach ( $productArray as $item ) {

        $wpdb->insert(
            $table_name,
            [
                'operation_type'  => 'product_create',
                'operation_value' => json_encode( $item ),
                'status'          => 'pending',
            ]
        );
    }

    echo '<h4>Products inserted successfully</h4>';

    return ob_get_clean();
}

add_shortcode( 'insert_product_api', 'insert_products_to_db_callback' );


// TRUNCATE Table
function truncate_table( $table_name ) {

    global $wpdb;
    $wpdb->query( "TRUNCATE TABLE $table_name" );

}